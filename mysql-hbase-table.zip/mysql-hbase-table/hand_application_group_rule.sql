/*
Navicat MySQL Data Transfer

Source Server         : 本地数据库
Source Server Version : 50632
Source Host           : localhost:3306
Source Database       : pinpoint

Target Server Type    : MYSQL
Target Server Version : 50632
File Encoding         : 65001

Date: 2017-09-26 14:03:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for hand_application_group_rule
-- ----------------------------
DROP TABLE IF EXISTS `hand_application_group_rule`;
CREATE TABLE `hand_application_group_rule` (
  `number` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_group_id` varchar(30) NOT NULL,
  `rule_id` varchar(30) NOT NULL,
  PRIMARY KEY (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
