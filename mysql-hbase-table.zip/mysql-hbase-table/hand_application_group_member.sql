/*
Navicat MySQL Data Transfer

Source Server         : 本地数据库
Source Server Version : 50632
Source Host           : localhost:3306
Source Database       : pinpoint

Target Server Type    : MYSQL
Target Server Version : 50632
File Encoding         : 65001

Date: 2017-09-26 14:03:28
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for hand_application_group_member
-- ----------------------------
DROP TABLE IF EXISTS `hand_application_group_member`;
CREATE TABLE `hand_application_group_member` (
  `number` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `application_group_id` varchar(30) NOT NULL,
  `member_id` varchar(50) NOT NULL,
  PRIMARY KEY (`number`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC;
